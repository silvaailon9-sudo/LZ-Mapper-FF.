package com.lzmapperff

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 20)
    private val panel = Color.rgb(36, 36, 43)
    private val red = Color.rgb(255, 57, 72)
    private val white = Color.WHITE
    private val prefs by lazy { getSharedPreferences("lz_settings", MODE_PRIVATE) }
    private lateinit var deviceStatus: TextView
    private lateinit var inputStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(bg)
        }
        scroll.addView(content)
        content.addView(label("LZ MAPPER FF", 29, red, true))
        content.addView(label("PAINEL GAMER • ANDROID / DEX", 11, Color.LTGRAY, true))
        content.addView(gap(18))
        content.addView(section("DISPOSITIVOS"))
        deviceStatus = label("Verificando dispositivos de entrada…", 14, white)
        content.addView(deviceStatus)
        content.addView(label("Conecte mouse ou teclado por USB, Bluetooth ou receptor 2.4 GHz. O Android pode reconhecê-los como periféricos HID.", 12, Color.LTGRAY))
        content.addView(gap(12))
        content.addView(section("SENSIBILIDADE — PERFIL DE REFERÊNCIA"))
        addSlider(content, "Geral", "geral", 190)
        addSlider(content, "Ponto vermelho", "red_dot", 185)
        addSlider(content, "Mira 2x", "scope_2x", 175)
        addSlider(content, "Mira 4x", "scope_4x", 160)
        addSlider(content, "AWM", "awm", 90)
        addSlider(content, "Olhadinha", "look", 150)
        content.addView(gap(10))
        content.addView(section("ATALHOS SUGERIDOS"))
        listOf(
            "Movimentar" to "W A S D", "Pular" to "SPACE", "Agachar" to "CTRL",
            "Recarregar" to "R", "Interagir" to "F", "Trocar arma" to "Q",
            "Atirar" to "Botão esquerdo", "Mirar" to "Botão direito"
        ).forEach { (action, key) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(panel)
            }
            row.addView(label(action, 14, white), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(key, 13, red, true))
            content.addView(row, match())
            content.addView(gap(4))
        }
        content.addView(gap(8))
        inputStatus = label("Última entrada: nenhuma", 12, Color.LTGRAY)
        content.addView(inputStatus)
        val save = Button(this).apply {
            text = "SALVAR PERFIL"
            setTextColor(white)
            setBackgroundColor(red)
            setOnClickListener { Toast.makeText(this@MainActivity, "Perfil salvo neste aparelho", Toast.LENGTH_SHORT).show() }
        }
        content.addView(save, match())
        content.addView(gap(10))
        content.addView(label("AVISO: esta versão é um painel de ajustes e leitura básica de eventos enquanto o app está em primeiro plano. Ela não injeta toques, não controla o Free Fire e não altera a sensibilidade do jogo. Mapeamento real exige integração Android específica e testes de compatibilidade.", 12, Color.LTGRAY))
        setContentView(scroll)
        refreshDevices()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (::inputStatus.isInitialized && event.action == KeyEvent.ACTION_DOWN) {
            inputStatus.text = "Teclado detectado: ${KeyEvent.keyCodeToString(event.keyCode)}"
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (::inputStatus.isInitialized && event.action == MotionEvent.ACTION_HOVER_MOVE) {
            inputStatus.text = "Movimento de mouse detectado"
        }
        return super.dispatchGenericMotionEvent(event)
    }

    private fun refreshDevices() {
        val devices = InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }
        val external = devices.filter { it.isExternal }
        val summary = if (external.isEmpty()) "Nenhum periférico externo detectado agora. Conecte mouse/teclado e reabra o painel." else
            external.joinToString("\n") { d ->
                val kinds = buildList {
                    if (d.supportsSource(InputDevice.SOURCE_MOUSE)) add("mouse")
                    if (d.supportsSource(InputDevice.SOURCE_KEYBOARD)) add("teclado")
                    if (d.supportsSource(InputDevice.SOURCE_TOUCHSCREEN)) add("touch")
                }.ifEmpty { listOf("entrada HID") }.joinToString(" + ")
                "• ${d.name} — $kinds"
            }
        deviceStatus.text = summary
    }

    private fun addSlider(parent: LinearLayout, title: String, key: String, default: Int) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 9, 14, 8); setBackgroundColor(panel) }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        line.addView(label(title, 14, white), LinearLayout.LayoutParams(0, -2, 1f))
        val value = label(prefs.getInt(key, default).toString(), 14, red, true)
        line.addView(value)
        val seek = SeekBar(this).apply {
            max = 200
            progress = prefs.getInt(key, default).coerceIn(0, 200)
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    value.text = p.toString()
                    if (fromUser) prefs.edit().putInt(key, p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(line); box.addView(seek)
        parent.addView(box, match()); parent.addView(gap(4))
    }

    private fun section(s: String) = label(s, 15, red, true).apply { setPadding(0, 7, 0, 7) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); setPadding(0, 3, 0, 3)
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private fun gap(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
