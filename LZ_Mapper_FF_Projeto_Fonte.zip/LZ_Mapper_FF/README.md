# LZ Mapper FF 1.0 — projeto-fonte Android

Projeto inicial em Kotlin para abrir no Android Studio ou compilar em CI (GitHub Actions).

## Incluído
- Interface escura com detalhes vermelhos.
- Sliders editáveis e persistidos localmente para valores de sensibilidade.
- Lista de atalhos sugeridos.
- Leitura básica dos dispositivos externos e eventos de teclado/mouse enquanto o painel está em primeiro plano.

## Limitações importantes
Este aplicativo **não é ainda um mapeador funcional dentro do Free Fire**. Não injeta toques, não captura o mouse em segundo plano e não altera as configurações do jogo. O painel não pode garantir que os valores sugeridos sejam melhores para sua mira. A integração de mapeamento exige APIs/permissões Android adequadas e validação no S23 Ultra/DeX; compatibilidade com o jogo não está confirmada.

## Compilar pelo celular (sem PC)
1. Crie uma conta em https://github.com/ e crie um repositório vazio chamado `LZ-Mapper-FF`.
2. Envie todos os arquivos desta pasta mantendo a estrutura.
3. No GitHub, abra **Actions** e configure um workflow Android/Gradle ou use o arquivo `.github/workflows/android.yml` se incluído numa próxima etapa.
4. O APK de debug deverá ser publicado como artefato do workflow após uma compilação bem-sucedida.

## Compilar localmente
Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35 e JDK 17.

O workflow `.github/workflows/android.yml` compila automaticamente quando você envia para `main`, ou manualmente em **Actions > Build LZ Mapper FF APK > Run workflow**. Depois abra a execução concluída e baixe `LZ-Mapper-FF-debug` em Artifacts.
